export const goalsOptions = [
    {
        label: "Learn Skills/Techniques",
        value: "Learn Skills/Techniques",
    },
    {
        label: "Exercise/Wellness",
        value: "Exercise/Wellness",
    },
    {
        label: "I Love Wrestling",
        value: "I Love Wrestling",
    },
    {
        label: "Win State Championship",
        value: "Win State Championship",
    },
    {
        label: "Win National Championship",
        value: "Win National Championship",
    },
    {
        label: "World Champion",
        value: "World Champion",
    },
    {
        label: "Olympic Champion",
        value: "Olympic Champion",
    },

]