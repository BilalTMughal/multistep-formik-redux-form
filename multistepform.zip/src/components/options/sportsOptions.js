export const sportsOptions = [
    {key: "Wrestling", value: 'Wrestling'},
    {key: "Jiu Jitsu/Grappling", value: 'Jiu Jitsu/Grappling'},
    {key: "Striking", value: 'Striking'},
    {key: "MMA", value: 'MMA'},
    {key: "Others", value: 'Others'},
]