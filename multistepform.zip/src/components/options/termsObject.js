export const termsObject = [
    {
        label: <>I have read and agreed to the <a href="#">Terms of Use</a> and the <a href="#">Privacy Policy</a></>,
        value: true,
        id: 124,
    }
]