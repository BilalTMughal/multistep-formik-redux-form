export const ageOptions = [
    {key: 'Yes', value: 'Yes'},
    {key: 'No', value: 'No'}
]