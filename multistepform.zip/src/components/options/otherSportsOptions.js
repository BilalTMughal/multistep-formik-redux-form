export const otherSportsOptions = [
    {label: "Wrestling", value: 'wrestling'},
    {label: "Jiu Jitsu/Grappling", value: 'Jiu Jitsu/Grappling'},
    {label: "Striking", value: 'Striking'},
    {label: "MMA", value: 'MMA'},
    {label: "Judo", value: 'Judo'},
    {label: "Sambo", value: 'Sambo'},
    {label: "Karate", value: 'Karate'},
    {label: "Gymnastics", value: 'Gymnastics'},
    {label: "Weightlifting", value: 'Weightlifting'},
    {label: "Football", value: 'Football'},
    {label: "Baseball", value: 'Baseball'},
    {label: "Basketball", value: 'Basketball'},
]