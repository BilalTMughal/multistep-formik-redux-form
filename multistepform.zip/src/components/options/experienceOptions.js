export const experienceOptions = [
    {label: '0-2', value: '0-2'},
    {label: '2-5', value: '2-5'},
    {label: '5-10', value: '5-10'},
    {label: '10-15', value: '10-15'},
    {label: '15+', value: '15+'}
]