export const professionOptions=[
    {label: "Yes", value: "Yes"},
    {label: "No", value: "No"} ,
]

